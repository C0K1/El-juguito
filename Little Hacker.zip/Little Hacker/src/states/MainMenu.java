package states;

import Basics.GameEngine;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

public class MainMenu extends State{

	public MainMenu(GameEngine game) {
		// Close Button*****************************************************************************
		super(game);
		Button close = new Button("x");
        close.getStyleClass().add("close");
        close.setTranslateX(300);
        close.setTranslateY(-225);
        close.setOnAction(new EventHandler<ActionEvent>()
        {
        	@Override

        	public void handle(ActionEvent event)
        	{
        		game.getPrimaryStage().close();
        	}
        });
        
        this.getChildren().add(close);
        // Start Button*****************************************************************************
        
        Button init = new Button("Iniciar");
        init.getStyleClass().add("init");
        init.setOnAction(new EventHandler<ActionEvent>()
        {
        	@Override

        	public void handle(ActionEvent event)
        	{
        		Game gameinit = new Game(game);
        	    game.setScene(gameinit, gameinit.getStyleSheet());
        	}
        });
        
        this.getChildren().add(init);
        
        // exit button
        
        Button exit = new Button("Salir");
        exit.getStyleClass().add("exit");
        exit.setOnAction(new EventHandler<ActionEvent>()
        {
        	@Override

        	public void handle(ActionEvent event)
        	{
        		game.getPrimaryStage().close();
        	}
        });
        exit.setTranslateX(0);
        exit.setTranslateY(100);
        this.getChildren().add(exit);
        
        
	}

	public  String getStyleSheet() {
		return this.getClass().getResource("/StyleSheets/main-menu.css").toExternalForm();
	}


}
