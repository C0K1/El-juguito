package states;

import Basics.GameEngine;

public class Game extends State{

	public Game(GameEngine game) {
		super(game);

	}

	@Override
	public String getStyleSheet() {
		// TODO Auto-generated method stub
		return this.getClass().getResource("/StyleSheets/game.css").toExternalForm();
	}

}
