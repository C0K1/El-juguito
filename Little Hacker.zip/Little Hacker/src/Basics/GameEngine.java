package Basics;

import java.io.FileInputStream;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class GameEngine extends Application{
	
	
	public static void main (String []args) {
		launch(args);
	}
	
	public void start(Stage primaryStage) throws Exception {
		 StackPane root = new StackPane();
		 	
	        root.setId("pane");
	        Scene scene = new Scene(root, 640, 480);
	        Button close = new Button();
	        Image image = new Image("/res/close.png");
	        ImageView iv = new ImageView(image);
	        iv.setPreserveRatio(true);
	        iv.setFitHeight(10);
	        close.setGraphic(iv);
	        close.setTranslateX(310);
	        close.setTranslateY(-225);
	        close.setOnAction(new EventHandler<ActionEvent>()
	        {
	        	@Override

	        	public void handle(ActionEvent event)
	        	{
	        		primaryStage.close();
	        	}
	        });

	        root.getChildren().add(close);
	        
	        scene.getStylesheets().addAll(this.getClass().getResource("/StyleSheets/main-menu.css").toExternalForm());
	        primaryStage.initStyle(StageStyle.UNDECORATED);
	        primaryStage.setScene(scene);
	        primaryStage.show();
		
		
	}

}
