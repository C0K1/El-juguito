package Stages;

import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;

public class MainMenu extends Stage{

	public MainMenu(Parent arg0) {
		super(arg0);

	}

	@Override
	public HBox addHBox() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public VBox addVBox() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addStackPane(HBox hb) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public GridPane addGridPane() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FlowPane addFlowPane() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TilePane addTilePane() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AnchorPane addAnchorPane(GridPane grid) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
