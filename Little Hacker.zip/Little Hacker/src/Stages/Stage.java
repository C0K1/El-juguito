package Stages;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.TilePane;
import javafx.scene.layout.VBox;

public abstract class Stage extends Scene{

	public Stage(Parent arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
    public abstract HBox addHBox();
    
/*
 * Creates a VBox with a list of links for the left region
 */
    public abstract VBox addVBox();

/*
 * Uses a stack pane to create a help icon and adds it to the right side of an HBox
 * 
 * @param hb HBox to add the stack to
 */
    public abstract void addStackPane(HBox hb);

/*
 * Creates a grid for the center region with four columns and three rows
 */
    public abstract GridPane addGridPane();

/*
 * Creates a horizontal flow pane with eight icons in four rows
 */
    public abstract FlowPane addFlowPane();
    
/*
 * Creates a horizontal (default) tile pane with eight icons in four rows
 */
    public abstract TilePane addTilePane();
 
/*
 * Creates an anchor pane using the provided grid and an HBox with buttons
 * 
 * @param grid Grid to anchor to the top of the anchor pane
 */
    public abstract AnchorPane addAnchorPane(GridPane grid);
}


