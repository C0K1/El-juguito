package GameBasics;

public class Launcher{
	
	public static void main(String[] args) {
		
		GameMainRunnable game = new GameMainRunnable();
		game.init();
		game.start();
		
	}
}